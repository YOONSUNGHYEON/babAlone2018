import pymysql as my
class DBHelper:
    '''
    멤버변수: 커넥션
    '''
    conn = None

    '''
    생성자
    '''

    def __init__(self):
        self.db_init()

    def db_init(self):
        self.conn = my.connect(
                            host='pythondb.clfc3vrmyheu.ap-northeast-2.rds.amazonaws.com',
                            user='root',
                            password='yu989898',
                            db='pythondb',
                            charset='utf8',
                            cursorclass=my.cursors.DictCursor)

        
    def db_free(self):
        if self.conn:
            self.conn.close()

    #검색 키워드 가져오기 => 웹에서 검색
    def db_selectKeyword(self):
        rows = None
        #커서 오픈
        with self.conn.cursor() as cursor:
            sql = "select * from tbl_rest2;"
            cursor.execute(sql)
            rows = cursor.fetchall()
            print(rows)
        return rows

        
    def db_insertCrawlingData(self, restName,menu, score, imgLink,link, content, arr, num, restTime, keyword):
        with self.conn.cursor() as cursor:
                sql ='''
                insert into `tbl_rest2`(restName,menu, score, imgLink,link, content, arr, num, restTime ,keyword)
                values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                '''
                cursor.execute(sql,(restName,menu, score, imgLink,link, content, arr, num, restTime, keyword))
        self.conn.commit()


if __name__ == '__main__':
    db = DBHelper()
    #print(db.db_selectKeyword())
    db.db_insertCrawlingData('1', '1', '1', '1', '1','1', '1', '1','1','1')
    db.db_free()