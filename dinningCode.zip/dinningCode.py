from selenium import webdriver as wd
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from Rest import RestInfo
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup
from DB import DBHelper as Db
MAIN_URL ='https://www.diningcode.com/'



#드라이버 로드
driver = wd.Chrome(executable_path='./chromedriver.exe')
driver.get(MAIN_URL)
db = Db()
keyword='혼밥 대구'

driver.find_element_by_id('s_input').send_keys(keyword, Keys.RETURN)
driver.find_element_by_xpath('//a[@href="/list.php?query=%s"]'% keyword).click()

restLink = [] #각각의 음식점 링크 리스트
restList = []

row = driver.find_elements_by_css_selector('.page_index_table>tbody>tr>.page-index-cell')

try:
    list = []
    #페이지 링크 받기
    for n in row:  
        link=None
        link=n.find_element_by_css_selector('a').get_attribute('href')
        list.append(link)  

    count = 0
    #페이지 돌리기
    for url in list:
        driver.get(url)
        #1페이지와 나머지 페이지가 식당 박스 클래스가 다름
        if count==0:
            boxItems = driver.find_elements_by_xpath('//div[@id="search_list"]/dc-restaurant')          
        else:
            boxItems = driver.find_elements_by_xpath('//div[@id="main_area"]/dc-restaurant')
        
        #각각의 식당 박스 돌기
        for dc in boxItems:
            #첫번째 박스는 광고라서 거르기
            if count==0:
                count+=1
                continue
            #식당사진링크
            imgLink = dc.find_element_by_css_selector('dc-restaurant-photo>.dc-restaurant-photo-container>dc-rimage>div').get_attribute('style').replace('background: url("','').replace('") center center no-repeat;','') 
            #식당이름
            restName = dc.find_element_by_css_selector('dc-restaurant-contents>.dc-restaurant-name>a').text
            #각각의 식당 링크
            link = dc.find_element_by_css_selector('dc-restaurant-contents>.dc-restaurant-name>a').get_attribute('href')
            #음식메뉴
            menu = dc.find_element_by_css_selector('dc-restaurant-contents>.dc-restaurant-category').text
            #점수
            score =  dc.find_element_by_css_selector('dc-restaurant-contents>.dc-restaurant-stat>.dc-restaurant-stat-item>.dc-restaurant-stat-item-count').text
            #contents, arr, num
            infos = dc.find_elements_by_css_selector('dc-restaurant-info>.dc-restaurant-info')
            contents = []
            for i in infos:
                contents.append(i.find_element_by_css_selector('.dc-restaurant-info-text').text)
            obj = RestInfo(restName, menu, score, imgLink, link, contents[0], contents[1], contents[2])
            restList.append(obj)
    print(len(restList))

    restTime = []
    for list in restList:
        driver.get(list.link)
        driver.implicitly_wait(1)
        list.restTime = driver.find_element_by_xpath('//div[@class="rest-time _flex_1"]/div[@class="rest-info-contents"]').text     
        db.db_insertCrawlingData(
            list.restName,
            list.menu,
            list.score,
            list.imgLink,
            list.link,
            list.content,
            list.arr,
            list.num,
            list.restTime,           
            keyword
        ) 
except Exception as e1:
    print("오류", e1)

driver.close()
driver.quit()
import sys
sys.exit()

#restMenu = driver.find_elements_by_xpath('//div[@class="rest-menu _flex_1"]/div[@class="rest-info-contents"]/div')
        #for rm in restMenu:
            #print(rm.find_element_by_css_selector('div.rest-menu-left').text)
            #print(rm.find_element_by_css_selector('div.rest-menu-right').text)
        