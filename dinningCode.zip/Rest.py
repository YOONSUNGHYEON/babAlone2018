class RestInfo:
    restName = ''
    menu = ''
    score = ''
    imgLink = ''
    link = ''
    content = ''
    arr=''
    num = ''
    restTime = ''



    def __init__(self, restName,menu, score, imgLink, link, content=None, arr=None, num=None, restTime=None):
        self.restName = restName
        self.menu = menu 
        self.score = score
        self.imgLink = imgLink
        self.link = link
        self.content = content
        self.arr = arr
        self.num = num
        self.restTime = restTime
        



